---
name: "logo-designer"
description: Designs editable brand logos for any type of business on a Claude Design canvas, always delivering three artboards - a primary logo, a reversed-color logo, and a standalone logo mark. Matches typeface, weight, case, spacing, mark style and palette to the business category (fashion, beauty, jewelry, bakery, cafe, tech, finance, wellness, fitness, kids, real estate and more). Use whenever the user asks for a logo, wordmark, logomark, brand mark, brand identity starting point, "a logo for my shop/startup/brand", a reversed or white version of a logo, or wants a logo made in Claude Design, even if they never say "canvas" or "logo-designer". Do not use for editing a user's existing raster logo file or for full brand-guideline documents.
---

# Logo Designer

Create a small, professional logo system for a business and deliver it as **live, editable artboards on a Claude Design canvas**. Every request produces exactly three artboards:

1. **Primary logo**: mark + wordmark (+ optional tagline), full color on a light ground
2. **Reversed logo**: the same logo recolored for a dark or brand-colored ground
3. **Logo mark**: the standalone symbol, usable alone (favicon, app icon, avatar, stamp)

"Editable" means the person can click into the wordmark and retype or restyle it, and the mark is inline vector shapes whose colors are adjustable. That is why text stays live text and the mark is hand-built inline SVG: never a raster image, and never text converted to outlines.

## Why vibe matters more than drawing

A logo is mostly typography plus one memorable idea. The same name feels like a different company depending on weight, stroke contrast, case, spacing and terminals. A bakery in hairline Didone caps reads as a boutique patisserie; a jeweler in chunky rounded sans reads as a toy shop. So the first job is choosing the right vibe for the category and committing to it. `references/industry-playbook.md` studies six reference logos (fashion, beauty, wardrobe boutique, jewelry, bakery, coffee) and gives recipes for 15+ business types. Read it before designing.

## Workflow

### 1. Intake: decide, don't interrogate
Needed: the **business name** and **what the business does**. Helpful but optional: tagline, audience, mood words, color preferences.

- If the name is missing, ask for it in one short question and stop. Nothing else should block the work.
- For everything else, decide and state the assumption in one line at the end. A concrete first design beats a questionnaire.
- If the user uploads reference logos, study their vibe (type feel, weight, spacing, mark approach); never copy their shapes or names.

### 2. Pick the vibe
Match the business to a recipe in the playbook. For hybrids (vegan skincare cafe), let one lead (about 70%) and borrow a single trait from the other. If nothing fits, derive the vibe from the levers in the playbook's cheat sheet.

### 3. Commit to a concept
Decide before building:
- **Typeface**: one Google Font for the wordmark, optionally a second for a small tagline. Google Fonts is the only external source the canvas allows. Always give a fallback stack.
- **Mark strategy**: exactly one from `references/logo-construction.md` (letter replacement, icon above, object built into letters, monogram + swash, accent glyph, arc tagline, ligature, badge). Choose from something true about the business or the letters in its name.
- **Palette**: 2 to 3 colors: `ink`, `ground`, optional `accent`. Then the reversed pair: a dark or saturated `ground-rev` and a light `ink-rev`. Use the playbook's palette starters as a starting point, not a default.
- **Copy**: keep the user's exact spelling and accents. Tagline: use theirs, or a short honest descriptor ("Coffee roasters", "Fine jewelry"), or none. No invented claims, years or awards.

### 4. Build the three artboards
Read `references/logo-construction.md` for drawing the mark, spacing the lockup, and deriving the reversed and mark-only versions. Start each artboard from `assets/board-template.dc.html`.

Create the canvas with the **Design** artifact type:
- Use the Artifact tool: `action: "list"`, `scope: "types"` to find the Design type, then `action: "read"` with its `type_url`. **Follow the returned instructions** for file shapes, folders and publishing. They are authoritative and can change between releases; the template here is only a starting skeleton.
- Canvas title: brand name + " Logo" (for example "Moki Logo").
- Artboards, in this order:
  - `Main.dc.html`: Primary logo, 960 x 600
  - `Reversed.dc.html`: Reversed logo, 960 x 600
  - `Logo-Mark.dc.html`: Logo mark, 600 x 600
- One row, 80 px apart, each with a clear `title` ("Primary logo", "Reversed logo", "Logo mark").
- Write and send one file at a time, `canvas.json` first, as the Design instructions require.
- Do not render, screenshot or read files back to verify unless the user asks.

If the Design type is not available, publish one self-contained HTML page showing the same three logos (live text + inline SVG) and say in one line that it is not a Design canvas.

### 5. Reply
Short: the canvas link, then 3 to 4 lines covering the concept (what the mark is and why), the typeface and palette hex codes, and assumptions. Mention the wordmark is live text they can click and edit, and colors are adjustable. Offer one concrete next step (for example a stacked layout or a darker palette), not a menu.

## Quality bar

- **One idea.** A hanger, sparkle, swash and badge together are four logos fighting. Pick one move; let typography carry the rest.
- **Legible small.** The mark reads at 32 px and in one color. No gradients, no hairlines thinner than about 2% of the mark's height.
- **Custom feel.** Alter at least one letterform or pair (swapped letter, joined ligature, accent) so it does not look like a font typed into a box.
- **Balanced lockup.** Optical centering; clear space around the lockup of at least the mark's main shape height; tagline no wider than the wordmark.
- **Reversed is designed, not inverted.** Light-on-dark thin strokes look thinner, so nudge weight or size up; keep contrast at 3:1 minimum for the mark and 4.5:1 for small text.
- **Mark is derived, not new.** The standalone mark comes from the primary logo's distinctive element, so the two always read as one brand.
- **No filler.** No stock photos, mockups on mugs or shopfronts, lorem ipsum, or invented facts. The deliverable is the logo system only.
- **Originality.** Never reproduce a known brand's mark or a reference image's shapes.

## Files
- `references/industry-playbook.md`: six-reference analysis, recipes by industry, vibe-to-lever cheat sheet, palette starters.
- `references/logo-construction.md`: mark strategies, starter SVG icons, lockup spacing, reversed and mark-only derivation, canvas rules.
- `assets/board-template.dc.html`: artboard skeleton with live-text wordmark, inline SVG mark and color tweaks.
