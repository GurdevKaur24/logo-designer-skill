# Industry Playbook

How logo vibe changes with business type. Contents:
1. What the six reference logos teach
2. Recipes by industry
3. Vibe-to-lever cheat sheet
4. Palette starters

All fonts are on Google Fonts (the canvas allows Google Fonts links).

---

## 1. What the six reference logos teach

| Reference (style only) | Business | Wordmark | The one idea | Tagline treatment | Color and mood |
|---|---|---|---|---|---|
| Pergola | Global fashion | Thin, airy, geometric-humanist sans with flowing joined letters (the "rg" connects) | Ligature between letters | Tiny, very widely tracked caps under the name | White ink on a muted olive fabric photo. Quiet, premium, minimal |
| Luminé | Beauty / skincare | Elegant high-contrast serif caps with an accent on the E | Monogram "L" with a calligraphic swash and a four-point sparkle | "BEAUTY CO." small, tracked, centered under the name | White on skin photography. Soft, glowing, feminine |
| Capsule | Wardrobe / boutique | Thin display serif with quirky, stretched lowercase and decorative joins | A clothes hanger rising from the letters (the object *is* the business) | None needed; icon does the explaining | Cream/white on soft neutral photo. Curated, editorial |
| Noor | Jewelry | Refined didone caps with hairline strokes, wide and symmetric | Two interlocking rings *as* the double "O" of NOOR, plus a tiny four-point star above | "JEWELRY" in clean tracked sans, much smaller | Pure white on black and white macro photo. Luxury, light, precious |
| Bakaré | Bakery | Fat, soft, retro display serif with swashy B and an accent on the E | Curved script tagline "The art of baking" arcing off the last letter | Handwritten script on an arc, tilted | Cream on warm caramel brown. Appetizing, handmade, nostalgic |
| Moki | Coffee cafe | Ultra-bold, rounded, bubbly sans with huge counters | The "O" is a coffee cup, with a steam wisp curling above the M | Bold all-caps sans, widely set, fills the width of the name | Deep cobalt blue on peach. Friendly, joyful, modern |

### Patterns to carry into any new logo
- **Weight tells you price and mood.** Hairline = luxury/quiet. Medium = trustworthy. Ultra-bold/rounded = friendly/approachable.
- **Contrast tells you tradition.** High stroke contrast (didone) = fashion, jewelry, beauty. Low contrast soft serif = warm, food, heritage. Monoline sans = modern, tech, casual.
- **Spacing tells you luxury.** Luxury brands are tracked wide and small; playful brands are tight and big.
- **The icon is born from a letter or the product**, never an unrelated clip-art symbol.
- **Ink is one color.** Photography or flat color provides the mood; the logo itself stays monochrome (or at most ink + one accent).
- **Taglines are an accessory.** Different font from the name, much smaller, aligned, often all caps with tracking, or a script when the brand is handmade.
- **Accents and diacritics (é, ï) add a "premium/foreign" flavor.** Use only if the name plausibly supports it, and mention it to the user.

---

## 2. Recipes by industry

Format: Type, Shape language, Icon idea, Palette, Tagline.

### Fashion / apparel (modern, minimal)
- **Type:** Light geometric or humanist sans, 200-300 weight, lowercase or Title case. Jost 300, Urbanist 300, Outfit 200, Quicksand 400.
- **Shape:** Open, airy, single-weight lines, one connecting ligature.
- **Icon:** Usually none. Optional: a joined letter pair or a hanger/stitch line.
- **Palette:** Off-white on olive/stone/charcoal, or black on cream.
- **Tagline:** "GLOBAL FASHION", "READY TO WEAR": 10-12% size, tracking 0.3-0.5em.

### Boutique / curated wardrobe / editorial fashion
- **Type:** Thin display serif, stylized. Italiana, Bellefair, Cormorant Garamond 300, Gloock.
- **Icon:** Object-as-logo: hanger, button, needle, tag, dress silhouette, merged into the top of the wordmark.
- **Palette:** Cream, sand, dusty rose, deep brown ink.
- **Tagline:** Often none.

### Beauty / skincare / cosmetics
- **Type:** High-contrast serif caps with generous spacing. Cormorant Garamond 500, Bodoni Moda 400, Playfair Display 400.
- **Icon:** Monogram with a calligraphic swash, plus a four-point sparkle (glow), droplet, or petal.
- **Palette:** Blush, nude, cream, soft taupe, optional deep plum or sage accent.
- **Tagline:** "BEAUTY CO.", "SKINCARE", "ATELIER": small, tracked sans (Jost 400).

### Jewelry / luxury accessories
- **Type:** Didone caps, hairline thin strokes, wide tracking, perfectly symmetric. Bodoni Moda, Cinzel, Marcellus, Playfair Display 400.
- **Icon:** Rings, gem facets, star, crown, or infinity form built from the letters; tiny four-point star as an accent above.
- **Palette:** Black + white, or ink on champagne gold (#C9A86A), deep emerald, navy.
- **Tagline:** "JEWELRY", "FINE JEWELLERY": tracked sans, tiny.

### Bakery / patisserie / desserts
- **Type:** Chunky, soft, retro serif with swashes. Caprasimo, Abril Fatface, DM Serif Display, Rozha One, Fraunces 900 (soft).
- **Shape:** Round, plump, slightly wobbly; swash on the first letter.
- **Icon:** Letter-embedded wheat ear, croissant curve, whisk, or a curved arc tagline in script.
- **Palette:** Caramel brown, butter yellow, cream, strawberry pink.
- **Tagline:** Script on an arc ("The art of baking"): Pacifico, Satisfy, Dancing Script, Kaushan Script.

### Cafe / coffee / tea
- **Type:** Ultra-bold rounded sans. Fredoka 600-700, Baloo 2 800, Lilita One, Nunito 900, Chewy.
- **Shape:** Soft corners, fat strokes, big counters (so a letter can become a cup).
- **Icon:** "O" as a cup/mug/bean/teapot; steam wisp over the neighboring letter.
- **Palette:** Cobalt on peach, tomato red on cream, forest green on oat, chocolate brown.
- **Tagline:** Bold all-caps, justified to the width of the name ("COFFEE WITH A LITTLE JOY").

### Restaurant / street food / bar
- **Type:** Characterful display: Bebas Neue (casual), Playfair Display Black (bistro), Bowlby One (bold diner), Yeseva One.
- **Icon:** Fork/knife/flame/pepper merged into a letter, or a circular badge.
- **Palette:** Tomato, mustard, deep green, charcoal; warm cream background.
- **Tagline:** Cuisine descriptor ("WOOD FIRED PIZZA"), tracked caps.

### Tech startup / SaaS / app
- **Type:** Geometric or grotesque sans, 600-700, tight tracking. Sora, Manrope, Space Grotesk, Outfit 600, Plus Jakarta Sans.
- **Icon:** Simple geometric symbol from the first letter (rounded square, node, bolt, orbit). Lowercase wordmark.
- **Palette:** One saturated hue (indigo, electric blue, violet, mint) on white or near-black.
- **Tagline:** Plain sentence case, light weight, or none.

### Fitness / sports / outdoor
- **Type:** Heavy condensed or italic sans: Anton, Oswald 700, Barlow Condensed 800 italic, Archivo Black.
- **Icon:** Dynamic slash, bolt, mountain, kettlebell shape in a letter. Angled cuts.
- **Palette:** Black + neon (lime, orange), or deep navy + red.
- **Tagline:** Imperative caps ("TRAIN HARD").

### Wellness / spa / yoga / meditation
- **Type:** Thin serif or light rounded sans, generous spacing. Cormorant Garamond 400, Jost 300, Marcellus.
- **Icon:** Lotus, leaf, arch, sun/moon, concentric circles; line-art, single stroke.
- **Palette:** Sage, sand, clay, soft sky; muted.
- **Tagline:** Lowercase or tracked caps, very small.

### Kids / toys / education (early years)
- **Type:** Round, wobbly, chunky. Fredoka, Baloo 2, Chewy, Grandstander, Sniglet.
- **Icon:** Smiley dot as letter counter, star, balloon, crayon swoosh; bouncing baseline (letters slightly offset).
- **Palette:** Primary-bright, 2 colors max for the logo (e.g. blue + sunny yellow).
- **Tagline:** Rounded sans, sentence case.

### Finance / legal / consulting
- **Type:** Classic serif or restrained sans. Libre Baskerville, Cormorant, Source Serif 4 600, Inter 600 tracked.
- **Icon:** Monogram in a shield/square/circle, or abstract pillar/arch.
- **Palette:** Navy, deep green, burgundy, gold accent.
- **Tagline:** "& PARTNERS", "ADVISORY", "LLP": tracked small caps.

### Healthcare / clinic / pharmacy
- **Type:** Friendly humanist sans. Nunito 700, Poppins 600, DM Sans 600.
- **Icon:** Cross/leaf/heart/droplet made from simple geometry, rounded.
- **Palette:** Teal, soft blue, green on white.
- **Tagline:** Plain, reassuring phrase.

### Real estate / architecture / interiors
- **Type:** Wide-tracked sans or elegant serif. Montserrat 300 tracked, Cormorant, Syncopate, Italiana.
- **Icon:** Roofline, door arch, window grid, or abstract building built from the first letter.
- **Palette:** Charcoal, warm gray, brass, forest.
- **Tagline:** "REALTY", "STUDIO", "INTERIORS".

### Craft brewery / barbershop / heritage workshop
- **Type:** Slab serif, blackletter-lite, vintage poster: Alfa Slab One, Rye, Bevan, Playfair Display Black, Special Elite.
- **Icon:** Badge/crest, hop, scissors, anvil; circular layout with arc text, "EST. 2024".
- **Palette:** Mustard, rust, deep teal, off-white; two-color print feel.
- **Tagline:** Arc text and "EST." line.

### Pet care / vet / grooming
- **Type:** Round friendly sans or soft serif. Fredoka, Baloo 2, Nunito, Recoleta-like Fraunces.
- **Icon:** Paw dot, ear, bone, or tail curl as a letter detail.
- **Palette:** Warm orange, teal, cream.

### Eco / organic / farm / grocery
- **Type:** Earthy soft serif or hand-cut sans. Fraunces, Lora, Josefin Sans, Gloock.
- **Icon:** Leaf as letter, sprout from a letter, sun over hill.
- **Palette:** Leaf green, soil brown, oat, tomato accent.

### Music / events / creative studio / photography
- **Type:** Expressive: Syne 800, Unbounded, Monoton (retro), Bodoni Moda italic, DM Serif Display italic.
- **Icon:** Waveform, aperture, play-triangle, or letter distorted by one bold move.
- **Palette:** High-contrast black + one vivid color; or gradients (only if requested).

---

## 3. Vibe-to-lever cheat sheet

| User says | Pull these levers |
|---|---|
| Luxury, premium | Hairline or high-contrast serif, wide tracking, small tagline, 1 color, black/white/gold |
| Minimal | Light weight, no icon (or a single ligature), lots of space |
| Playful, fun | Rounded bold font, saturated color, letter turned into object, slight rotation/bounce |
| Warm, handmade | Soft serif or script accent, earthy palette, imperfect curves, arc text |
| Modern, techy | Geometric sans, tight tracking, lowercase, single hue, simple geometric icon |
| Elegant, feminine | Didone/swash serif, blush/nude palette, sparkle or petal accent |
| Bold, strong | Heavy condensed sans, uppercase, angular cut, black + vivid accent |
| Trustworthy | Mid-weight serif or humanist sans, navy/green, symmetrical layout |
| Vintage / retro | Fat serif or slab, two-color palette, badge shapes, arc text |

## 4. Palette starters (ink on background)

| Mood | Ink | Background |
|---|---|---|
| Quiet fashion | #F4F1EA | #4B4A2B |
| Glow beauty | #FFFFFF | #C98F7B |
| Noir luxury | #FFFFFF | #0B0B0B |
| Warm bakery | #FFF3E0 | #8A4B2A |
| Joyful cafe | #1F4FB5 | #FDE6D9 |
| Fresh tech | #FFFFFF | #4F46E5 |
| Spa calm | #5E6B58 | #EFEADF |
| Heritage badge | #1E3A34 | #E9C46A |
| Finance | #C9A86A | #14213D |
| Kids | #2F6FED | #FFE066 |
