# Logo Construction on a Design Canvas

Contents:
1. Mark strategies (pick ONE)
2. Starter icons (inline SVG)
3. Lockup spacing
4. Deriving the reversed logo
5. Deriving the logo mark
6. Editability and canvas rules

---

## 1. Mark strategies (pick ONE)

| Strategy | Best for | How to build |
|---|---|---|
| **Letter replacement** | Cafe, food, kids, tech, pets | Replace a round letter (O, C, D, Q, A) with an inline SVG object the same height as the x-height or cap height. Wrap the word in a flex row: `<span>M</span><svg/><span>KI</span>` so letters stay editable |
| **Icon above** | Boutique, jewelry, beauty | Small symbol centered above the wordmark, about 0.5x the cap height, with a gap of about 0.25x its own height |
| **Object built into letters** | Boutique, jewelry | Two rings as a double O, a hanger rising from the letters. Position the SVG absolutely over the text with `position: relative` on the wordmark box |
| **Monogram + swash** | Beauty, fashion, law | Large initial in the wordmark font, plus a thin swash path under or beside it; full name set small below |
| **Accent glyph** | Luxury | A four-point sparkle or a diacritic (é) placed after or above one letter |
| **Arc tagline** | Bakery, brewery, handmade | Script tagline on a curved `<textPath>` rising off the last letter (see below) |
| **Ligature** | Minimal fashion | Connect two letters with a thin SVG stroke between them, or pick a font that already ligates the pair |
| **Badge / crest** | Heritage, craft | Circle with arc text and the name inside; mark-only version drops the arc text |

Choose from something true about the business or the name: a cup becomes the O in "Moki" because the name has an O and coffee has cups. No unrelated clip-art.

## 2. Starter icons (inline SVG)

Draw each in a `viewBox="-50 -50 100 100"` so shapes are centered on (0,0). Use `fill="currentColor"` or `stroke="currentColor"` so the wrapper's CSS `color` (set from the `ink` tweak) controls it. For a second color, give those elements `style="fill: {{accent}}"`.

**Four-point sparkle** (beauty, luxury)
```svg
<path fill="currentColor" d="M0,-50 C4,-18 18,-4 50,0 C18,4 4,18 0,50 C-4,18 -18,4 -50,0 C-18,-4 -4,-18 0,-50Z"/>
```
**Coffee cup with steam** (cafe)
```svg
<path fill="currentColor" d="M-36,-12 H24 V12 C24,30 10,40 -6,40 C-22,40 -36,30 -36,12Z"/>
<path fill="none" stroke="currentColor" stroke-width="9" stroke-linecap="round" d="M24,-4 H32 C44,-4 44,18 30,18 H23"/>
<path fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" d="M-8,-24 C-18,-32 -2,-40 -8,-50"/>
```
**Hanger** (boutique)
```svg
<path fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M0,-6 V-14 C0,-24 12,-28 12,-38 C12,-48 -2,-50 -6,-42 M0,-6 L-48,26 H48 Z"/>
```
**Interlocking rings** (jewelry)
```svg
<circle cx="-17" cy="0" r="30" fill="none" stroke="currentColor" stroke-width="4"/>
<circle cx="17" cy="0" r="30" fill="none" stroke="currentColor" stroke-width="4"/>
```
**Sun** (wellness)
```svg
<circle r="17" fill="currentColor"/>
<path fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" d="M0,-32 V-46 M0,32 V46 M-32,0 H-46 M32,0 H46 M-23,-23 L-33,-33 M23,23 L33,33 M-23,23 L-33,33 M23,-23 L33,-33"/>
```
**Leaf** (eco, organic) - vein in the ground color via `style="stroke: {{ground}}"`
```svg
<path fill="currentColor" d="M0,44 C-32,24 -36,-18 0,-46 C36,-18 32,24 0,44Z"/>
<path fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" d="M0,38 V-18"/>
```
**Droplet** (beauty, health)
```svg
<path fill="currentColor" d="M0,-46 C24,-14 32,-2 32,14 A32,32 0 0 1 -32,14 C-32,-2 -24,-14 0,-46Z"/>
```
**Crescent** (spa, sleep)
```svg
<path fill="currentColor" d="M18,-42 A44,44 0 1 0 18,42 A32,32 0 1 1 18,-42Z"/>
```
**Heart** (care, kids, pets)
```svg
<path fill="currentColor" d="M0,40 C-52,4 -34,-40 -14,-30 C-6,-26 0,-18 0,-18 C0,-18 6,-26 14,-30 C34,-40 52,4 0,40Z"/>
```
**Bolt** (tech, fitness)
```svg
<path fill="currentColor" d="M10,-50 L-28,6 H-4 L-12,50 L30,-10 H4Z"/>
```
**Paw** (pets)
```svg
<ellipse cx="0" cy="18" rx="22" ry="18" fill="currentColor"/>
<ellipse cx="-30" cy="-6" rx="9" ry="12" fill="currentColor"/>
<ellipse cx="-11" cy="-26" rx="9" ry="13" fill="currentColor"/>
<ellipse cx="11" cy="-26" rx="9" ry="13" fill="currentColor"/>
<ellipse cx="30" cy="-6" rx="9" ry="12" fill="currentColor"/>
```
**Arch / window** (interiors, real estate)
```svg
<path fill="none" stroke="currentColor" stroke-width="7" d="M-30,44 V-8 A30,30 0 0 1 30,-8 V44 Z"/>
```

Design your own when none fit: 1 to 3 shapes, one consistent stroke width, rounded caps and joins for rounded type, butt and miter for formal type. Always give decorative SVG `aria-hidden="true"` when the brand name is also present as text; give a standalone mark `role="img"` and `aria-label="<Brand> logo mark"`.

### Arc text (curved tagline)
```svg
<svg viewBox="0 0 200 90" width="200" height="90" aria-hidden="true">
  <defs><path id="tag-arc" d="M 4,80 Q 70,10 190,12"/></defs>
  <text font-size="26" fill="currentColor" style="font-family: 'Satisfy', cursive">
    <textPath href="#tag-arc">The art of baking</textPath>
  </text>
</svg>
```
Circular badge: use a full-circle path and `startOffset="50%"` with `text-anchor="middle"`.

### Ligature and swash notes
- Ligature stroke: a thin `<path>` linking the exit of letter A to the entry of letter B; stroke width about `font-size / 45` for light weights.
- If a font already has a beautiful swash or ligature (Abril Fatface, Caprasimo, Playfair Display italic), choose it and skip hand-drawing.

## 3. Lockup spacing

Use these as starting ratios, with `H` = the wordmark's font-size.

| Element | Luxury / quiet | Friendly / bold |
|---|---|---|
| Wordmark tracking | 0.12 to 0.35em | -0.02 to 0.02em |
| Tagline size | 0.12 to 0.18 H | 0.18 to 0.3 H |
| Tagline tracking | 0.3 to 0.6em | 0.04 to 0.12em |
| Gap wordmark to tagline | 0.2 to 0.3 H | 0.1 to 0.2 H |
| Gap mark to wordmark (stacked) | 0.25 to 0.4 H | 0.15 to 0.25 H |
| Clear space around lockup | at least 0.5 H | at least 0.4 H |

Center everything optically on one vertical axis. Tracked text carries trailing letter-spacing after the last letter, so add `padding-left` equal to the tracking value (or `margin-right: -<tracking>`) to re-center. Keep the tagline no wider than the wordmark. On a 960 x 600 board, size the whole lockup to fill roughly 45 to 60% of the width.

## 4. Deriving the reversed logo

Same lockup, same proportions, different ground. This is a designed variant, not a color invert.

1. Ground becomes `ground-rev`: the brand's deepest color, or a saturated brand color (not pure black unless the brand is noir luxury).
2. Ink becomes `ink-rev`: a warm or cool off-white matched to the palette (cream, blush, pale mint), rarely pure #FFFFFF.
3. The accent shifts if needed. Keep it distinguishable from the ground at 3:1 or better.
4. Compensate optical thinning: light text on dark appears lighter, so raise font-weight one step (e.g. 300 to 400) or add 2 to 4% to hairline strokes if the type is very thin.
5. Elements that used the ground color (a leaf vein, a cutout) now use `ground-rev`.
6. Check contrast: mark and large text 3:1 minimum, tagline 4.5:1.

Implement it as the same artboard markup as `Main.dc.html` with different `data-props` defaults, so editing one color tweak updates only that board.

## 5. Deriving the logo mark

The standalone mark must work with no text at all.

- Take the primary logo's distinctive element: the swapped-letter icon, the monogram, the rings, the hanger, the sparkle, or the first letter in the wordmark font.
- No distinctive element (pure wordmark logos)? Build the mark from the initial letter, with the same ligature, swash or terminal treatment as the wordmark.
- Single color, solid shapes, nothing finer than about 2% of the mark's height. It must survive at 32 px.
- Composition: centered in the 600 x 600 board, occupying about 45 to 55% of the width, so there is room for avatar and icon crops.
- Optional container: a circle or rounded square in `ink`, with the mark knocked out in `ground`, when the raw symbol is too light or irregular to read as an avatar. Use the container only if it helps; the bare mark is the default.
- Board background: `ground` (light). Do not add a second, reversed mark board; the reversed logo board already proves the dark treatment.

## 6. Editability and canvas rules

- Wordmark: live HTML text in a Google Font, set with inline `style` (font-family, size, weight, letter-spacing, color) so the properties panel can edit it. Never outline text.
- Brand name and tagline are literal markup, not template holes, so a viewer can retype them directly.
- Declare tweaks in `data-props`: `ink`, `ground`, `accent` as color editors. Defaults are the palette for that board.
- Mark: inline `<svg>` with `currentColor`. Wrap it in a container that sets `color: {{ink}}`.
- Fonts: one `<link>` to `fonts.googleapis.com/css2` inside `<helmet>`, and a fallback stack in every `font-family`.
- No images, no `data:` URIs, no emoji, no network calls besides the Google Fonts link.
- Every artboard root has a fixed `width` and `height` equal to its board size (it is a fixed-size piece, not a page).
- Follow the Design type's returned instructions where they differ from anything here.
